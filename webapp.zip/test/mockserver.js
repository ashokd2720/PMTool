sap.ui.define([
	"sap/ui/core/util/mockServer"
], function (mockServer) {
	"use strict";
	return {
		init: function () {
			// create
			var oMockServer = new mockServer({
				rootUri: "/destinations//sap/opu/odata/sap/ZTECH_TRACKER_SRV/"
			}); 
			var oUriParameters = jQuery.sap.getUriParameters();
			// configure
			mockServer.config({
				autoRespond: true,
				autoRespondAfter: oUriParameters.get("serverDelay") || 1000
			});
			// simulate
			var sPath = jQuery.sap.getModulePath("ZNav.localService");
			oMockServer.simulate(sPath + "/metadata.xml", sPath + "/mockdata");
			// start
			oMockServer.start();
		}
	};
});