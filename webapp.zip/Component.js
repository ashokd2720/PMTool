sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZNav/model/models",
	"sap/ui/model/json/JSONModel",
], function(UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("ZNav.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			
			         // set data model
         var oData = {
                        editable : false
             };
             
         var oModel = new JSONModel(oData);
         sap.ui.getCore().setModel(oModel, "Edit");
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			// enable hash based routing
			this.getRouter().initialize();
		}
	});
});